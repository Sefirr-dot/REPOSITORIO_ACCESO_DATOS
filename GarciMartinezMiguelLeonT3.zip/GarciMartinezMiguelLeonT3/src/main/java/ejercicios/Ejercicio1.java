import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import clases.ResumenCamisetasId;

import java.util.List;

public class Ejercicio1 {

    public void llenarResumenCamisetas(Session session) {
        Transaction transaction = session.beginTransaction();
        try {
            // Consulta para obtener los ciclistas que han llevado camisetas con premio
            String hql = "SELECT c.codigociclista, c.nombreciclista, l.codigocamiseta, COUNT(l.codigocamiseta), SUM(cam.importepremio) " +
                         "FROM LLEVA l " +
                         "JOIN CAMISETAS cam ON l.codigocamiseta = cam.codigocamiseta " +
                         "JOIN CICLISTAS c ON l.codigociclista = c.codigociclista " +
                         "GROUP BY c.codigociclista, l.codigocamiseta ORDER BY c.codigociclista";
            Query<Object[]> query = session.createQuery(hql, Object[].class);
            List<Object[]> results = query.getResultList();

            // Llenar la tabla RESUMEN_CAMISETAS
            for (Object[] result : results) {
                int codigociclista = (int) result[0];
                String nombreCiclista = (String) result[1];
                int codigocamiseta = (int) result[2];
                int numVeces = (int) result[3];
                float importePremio = (float) result[4];

                // Crear el objeto ResumenCamisetas
                ResumenCamisetasId id = new ResumenCamisetasId(/* Aquí debes proporcionar el codigoequipo correspondiente */, codigociclista, codigocamiseta);
                ResumenCamisetas resumen = new ResumenCamisetas(id, new Camisetas(codigocamiseta), new Ciclistas(codigociclista, nombreCiclista), null, numVeces, importePremio);
                
                // Guardar en la base de datos
                session.save(resumen);
                System.out.println("Insertado: " + codigociclista + " " + nombreCiclista + " " + numVeces + " " + importePremio);
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}