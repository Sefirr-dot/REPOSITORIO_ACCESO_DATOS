package ejercicios;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import clases.Ciclistas;
import clases.Equipos;

import java.util.HashSet;
import java.util.Set;

public class Ejercicio2 {

    // Método para obtener el equipo y sus ciclistas desde la base de datos
    public static void mostrarResumenCiclistas(int codigoEquipo) {
        // Crear la sesión de Hibernate y la SessionFactory
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Equipos.class)
                .addAnnotatedClass(Ciclistas.class)
                .buildSessionFactory();

        // Iniciar sesión
        Session session = factory.getCurrentSession();

        // Obtener el equipo con el código proporcionado
        Equipos equipo = obtenerEquipoPorCodigo(session, codigoEquipo);

        // Verificar si el equipo existe
        if (equipo == null) {
            System.out.println("El equipo con el código " + codigoEquipo + " no existe.");
            factory.close();
            return;
        }

        // Obtener los ciclistas del equipo
        Set<Ciclistas> ciclistas = equipo.getCiclistases();

        // Verificar si el equipo tiene ciclistas
        if (ciclistas.isEmpty()) {
            System.out.println("El equipo " + equipo.getNombreequipo() + " no tiene ciclistas.");
            factory.close();
            return;
        }

        // Mostrar la información básica del equipo
        System.out.println("COD-EQUIPO: " + equipo.getCodigoequipo() + "   NOMBRE: " + equipo.getNombreequipo());
        System.out.println("PAIS: " + equipo.getPais() + ", Jefe de Equipo: " + equipo.getDirector());
        System.out.println("---------------------------------------------------------------------------------------------------");
        System.out.println("CODIGO  NOMBRE                                        Etapas Ganadas  Tramos Ganados  Nº VecesCamiseta");
        System.out.println("======  ============================================  ===============  ===============  ===============");

        int maxEtapas = -1;
        int maxTramos = -1;
        Set<String> maxEtapasCiclistas = new HashSet<>();
        Set<String> maxTramosCiclistas = new HashSet<>();

        // Iterar sobre los ciclistas para mostrar los detalles
        for (Ciclistas ciclista : ciclistas) {
            // Calcular el número de etapas ganadas, tramos ganados y camisetas de premio
            int etapasGanadas = ciclista.getEtapases().size();
            int tramosGanados = ciclista.getTramospuertoses().size();
            int camisetaPremio = ciclista.getResumenCamisetases().size();

            // Mostrar el resumen del ciclista
            System.out.printf("%6d  %-45s  %15d  %15d  %15d%n", ciclista.getCodigociclista(), ciclista.getNombreciclista(),
                    etapasGanadas, tramosGanados, camisetaPremio);

            // Determinar los ciclistas con más etapas ganadas
            if (etapasGanadas > maxEtapas) {
                maxEtapas = etapasGanadas;
                maxEtapasCiclistas.clear();  // Limpiar los anteriores
                maxEtapasCiclistas.add(ciclista.getNombreciclista());
            } else if (etapasGanadas == maxEtapas) {
                maxEtapasCiclistas.add(ciclista.getNombreciclista());
            }

            // Determinar los ciclistas con más tramos ganados
            if (tramosGanados > maxTramos) {
                maxTramos = tramosGanados;
                maxTramosCiclistas.clear();  // Limpiar los anteriores
                maxTramosCiclistas.add(ciclista.getNombreciclista());
            } else if (tramosGanados == maxTramos) {
                maxTramosCiclistas.add(ciclista.getNombreciclista());
            }
        }

        System.out.println("======  ============================================  ===============  ===============  ===============");

        // Mostrar los ciclistas con más etapas ganadas
        System.out.print("Nombre/s de corredor/es con más etapas ganadas: ");
        if (!maxEtapasCiclistas.isEmpty()) {
            System.out.println(String.join(", ", maxEtapasCiclistas));
        } else {
            System.out.println("No hay");
        }

        // Mostrar los ciclistas con más tramos ganados
        System.out.print("Nombre/s de corredor/es con más tramos ganados: ");
        if (!maxTramosCiclistas.isEmpty()) {
            System.out.println(String.join(", ", maxTramosCiclistas));
        } else {
            System.out.println("No hay");
        }

        // Cerrar la sesión y la fábrica de sesiones
        session.close();
        factory.close();
    }

    // Método para obtener el equipo por código desde la base de datos
    private static Equipos obtenerEquipoPorCodigo(Session session, int codigoEquipo) {
        String hql = "FROM Equipos e LEFT JOIN FETCH e.ciclistases WHERE e.codigoequipo = :codigoEquipo";
        Query<Equipos> query = session.createQuery(hql, Equipos.class);
        query.setParameter("codigoEquipo", codigoEquipo);
        return query.uniqueResult();
    }

    public static void main(String[] args) {
        // Ejecutar el método con el código del equipo 4
        mostrarResumenCiclistas(4);
    }
}
