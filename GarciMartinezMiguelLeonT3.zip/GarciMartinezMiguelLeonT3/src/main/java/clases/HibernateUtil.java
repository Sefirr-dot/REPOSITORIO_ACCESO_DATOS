package clases;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
    private static SessionFactory sessionFactory;

    static {
        try {
            // Crear la SessionFactory a partir de la configuración de Hibernate
            sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(ResumenCamisetas.class)
                                                 .addAnnotatedClass(Ciclistas.class).addAnnotatedClass(Equipos.class)
                                                 .addAnnotatedClass(Camisetas.class).buildSessionFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
